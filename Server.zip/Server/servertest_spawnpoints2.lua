function SpawnPoints()
	return {
		unemployed = {
			{ worldX = 35, worldY = 31, posX = 118, posY = 111 }
		}
	}
end

